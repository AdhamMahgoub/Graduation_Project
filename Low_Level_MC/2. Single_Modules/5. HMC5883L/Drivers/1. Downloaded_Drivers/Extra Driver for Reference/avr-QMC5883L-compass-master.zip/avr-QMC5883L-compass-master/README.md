# avr-QMC5883L-compass
QMC5883L digital compas library + test

In some GY-271 boards QMC5883L is used instead HMC5883L
